# Stage 0 — Simple Enterprise Policy Agent

This is Stage 0 of the staged build plan: a FastAPI server that receives a
question, a local LLM that decides whether to call `search_policies()`,
`search_employee()`, or `list_documents()`, Qdrant holding embedded policy
documents, and DuckDB holding employee records — with a Streamlit chat box
on top.

It uses a **local, open-weight model via Ollama** instead of a paid
OpenAI/Anthropic API key, so there's nothing to pay for and no API key to
manage. Swapping to a hosted API later is a small, isolated change (see
`app/agent.py`).

## Why you're running this yourself, not me

I built and generated everything in this project (all the code, the sample
policy PDFs, `employees.csv`), but I could not install any packages or
download the Ollama model myself — this Cowork session's network is locked
to an allowlist that blocks PyPI, npm, and ollama.com, both in the cloud
workspace and in the local device bridge's sandboxed VM. That's a Cowork
network-egress setting, not something wrong with the project.

So: open a normal Terminal on your Mac (not through Claude) and run the
steps below there. If you'd rather run it through Cowork, an org
owner can change the network egress mode under **Settings → Capabilities**
first — but that only takes effect in a brand-new session, not this one.

## 1. Install Ollama and pull the models

```bash
# macOS
brew install ollama
# or download from https://ollama.com/download

ollama serve &        # if it isn't already running as a background service
ollama pull qwen2.5:1.5b       # small, fast, supports tool-calling — good for a laptop CPU
ollama pull nomic-embed-text   # embedding model
```

If your Mac can comfortably run something bigger (8B+), `qwen2.5:7b` or
`llama3.1:8b` will give noticeably better answers — just change
`OLLAMA_CHAT_MODEL` in `.env` (copy `.env.example` to `.env` first).

## 2. Set up the Python environment

```bash
cd policy-agent
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## 3. Ingest the sample documents

The sample HR policy PDFs (`data/policies/*.pdf`) and `data/employees.csv`
are already generated and included. To regenerate or replace them with your
own:

```bash
python scripts/generate_sample_data.py   # optional — only if you want to regenerate the samples
```

Then load everything into Qdrant (local, on-disk — no Docker needed):

```bash
python -m app.ingest
```

You should see output like:

```
Found 5 policy PDF(s): ...
Total chunks: NN
Embedding with Ollama model 'nomic-embed-text' ...
Ingested NN chunks from 5 documents into Qdrant collection 'policies' at ./qdrant_data
```

## 4. Run the smoke test (matches the plan's acceptance criteria)

```bash
python scripts/smoke_test.py
```

This asks "Can interns work remotely?" (should call `search_policies`) and
"Who manages Alice?" (should call `search_employee`) directly through the
agent, with no server needed, and tells you pass/fail.

## 5. Run the full app

In one terminal:

```bash
uvicorn app.main:app --reload --port 8000
```

In another terminal:

```bash
streamlit run app/streamlit_app.py
```

Open the Streamlit URL it prints (usually http://localhost:8501) and try:

- "Can interns work remotely?"
- "Who manages Alice?"
- "How many PTO days do I get?"
- "What's the dog-walking policy?" (should say it doesn't know — Stage 1 makes this more robust)

Expand "Tool calls" under any answer to see exactly which tool fired and
what it returned — that's how you verify the routing the plan's acceptance
test asks for.

## A note on Qdrant's local mode

`QdrantClient(path=...)` (used here to avoid needing Docker) locks the
`qdrant_data/` folder for exclusive access — only one process can have it
open at a time. So: stop `uvicorn` before re-running `python -m app.ingest`
or `python scripts/smoke_test.py`, then start `uvicorn` again afterwards.
If you outgrow this, swap to a real Qdrant server (`docker run -p 6333:6333
qdrant/qdrant`, then `QdrantClient(url="http://localhost:6333")` in
`app/ingest.py` and `app/tools.py`) and this limitation goes away.

## Project layout

```
policy-agent/
  data/
    policies/*.pdf       synthetic sample HR policy documents
    employees.csv        synthetic sample employee roster
  app/
    config.py            all settings, env-var overridable
    ingest.py             PDF -> chunks -> embeddings -> Qdrant
    db.py                 DuckDB connection over employees.csv
    tools.py               search_policies / search_employee / list_documents
    agent.py                tool-calling loop around a local Ollama model
    main.py                  FastAPI server (POST /chat)
    streamlit_app.py          chat UI
  scripts/
    generate_sample_data.py  (re)generate the sample PDFs + CSV
    smoke_test.py             the plan's Stage 0 acceptance test
  requirements.txt
  .env.example
```

## You're done with Stage 0 when...

...`scripts/smoke_test.py` passes both cases, and you can ask both kinds of
questions in the Streamlit UI and get correct answers end-to-end with no
manual intervention. From there, Stage 1 wraps this same agent in a
LangGraph self-healing loop — nothing here needs to change, it just gets
wrapped.
