"""
Central configuration for the Stage 0 Policy Agent.

Everything is overridable via environment variables (see .env.example),
so nothing here is hardcoded that a real deployment would need to change.
"""
import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent

# --- Ollama (local LLM + embeddings) ---------------------------------------
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
OLLAMA_CHAT_MODEL = os.getenv("OLLAMA_CHAT_MODEL", "qwen2.5:1.5b")
OLLAMA_EMBED_MODEL = os.getenv("OLLAMA_EMBED_MODEL", "nomic-embed-text")

# --- Qdrant (local, on-disk — no Docker/server required) -------------------
QDRANT_PATH = os.getenv("QDRANT_PATH", str(BASE_DIR / "qdrant_data"))
QDRANT_COLLECTION = os.getenv("QDRANT_COLLECTION", "policies")

# --- Data sources ------------------------------------------------------------
POLICIES_DIR = os.getenv("POLICIES_DIR", str(BASE_DIR / "data" / "policies"))
EMPLOYEES_CSV = os.getenv("EMPLOYEES_CSV", str(BASE_DIR / "data" / "employees.csv"))

# --- Chunking ----------------------------------------------------------------
CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", "800"))
CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", "120"))

# --- Agent loop ---------------------------------------------------------------
MAX_TOOL_ITERATIONS = int(os.getenv("MAX_TOOL_ITERATIONS", "5"))

# --- FastAPI / Streamlit -------------------------------------------------------
API_HOST = os.getenv("API_HOST", "127.0.0.1")
API_PORT = int(os.getenv("API_PORT", "8000"))
