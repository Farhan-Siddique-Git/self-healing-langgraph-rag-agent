"""
Stage 0, step 5 (frontend half): a Streamlit chat box on top of the FastAPI
server.

Run:  streamlit run app/streamlit_app.py
(Make sure `uvicorn app.main:app --port 8000` is already running in another
terminal — this UI just calls that API.)
"""
import requests
import streamlit as st

from app import config

API_URL = f"http://{config.API_HOST}:{config.API_PORT}/chat"

st.set_page_config(page_title="Acme Corp HR Assistant (Stage 0)", page_icon="💬")
st.title("💬 Acme Corp HR Assistant")
st.caption(
    "Stage 0 MVP — ask about company policy (remote work, PTO, expenses, "
    "conduct, security) or about a colleague (manager, department, title)."
)

if "history" not in st.session_state:
    st.session_state.history = []  # list of {"role": "user"/"assistant", "content": str, "tool_calls": [...]}

for turn in st.session_state.history:
    with st.chat_message(turn["role"]):
        st.markdown(turn["content"])
        if turn.get("tool_calls"):
            with st.expander("Tool calls"):
                for call in turn["tool_calls"]:
                    st.markdown(f"**{call['name']}**(`{call['args']}`)")
                    st.text(call["result"])

user_input = st.chat_input("Ask a question, e.g. 'Can interns work remotely?'")

if user_input:
    st.session_state.history.append({"role": "user", "content": user_input})
    with st.chat_message("user"):
        st.markdown(user_input)

    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            try:
                resp = requests.post(API_URL, json={"message": user_input}, timeout=120)
                resp.raise_for_status()
                data = resp.json()
                answer = data["answer"]
                tool_calls = data.get("tool_calls", [])
            except requests.RequestException as exc:
                answer = (
                    f"Couldn't reach the API at {API_URL} ({exc}). "
                    "Is `uvicorn app.main:app --port 8000` running?"
                )
                tool_calls = []

        st.markdown(answer)
        if tool_calls:
            with st.expander("Tool calls"):
                for call in tool_calls:
                    st.markdown(f"**{call['name']}**(`{call['args']}`)")
                    st.text(call["result"])

    st.session_state.history.append(
        {"role": "assistant", "content": answer, "tool_calls": tool_calls}
    )
