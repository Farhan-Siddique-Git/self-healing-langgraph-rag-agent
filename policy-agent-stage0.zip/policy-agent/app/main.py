"""
Stage 0, step 5 (backend half): a FastAPI server that receives a question
and runs it through the agent loop.

Run directly:      uvicorn app.main:app --reload --port 8000
Or:                 python -m app.main
"""
from __future__ import annotations

from fastapi import FastAPI
from pydantic import BaseModel

from app import config
from app.agent import run_agent

app = FastAPI(title="Policy Agent — Stage 0")


class ChatRequest(BaseModel):
    message: str


class ToolCallRecord(BaseModel):
    name: str
    args: dict
    result: str


class ChatResponse(BaseModel):
    answer: str
    tool_calls: list[ToolCallRecord]


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}


@app.post("/chat", response_model=ChatResponse)
def chat(request: ChatRequest) -> ChatResponse:
    result = run_agent(request.message)
    return ChatResponse(answer=result["answer"], tool_calls=result["tool_calls"])


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app.main:app", host=config.API_HOST, port=config.API_PORT, reload=True)
