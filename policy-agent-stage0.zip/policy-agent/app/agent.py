"""
Stage 0, step 4: give an LLM function-calling access to the three tools.

This uses a local, open-weight model served by Ollama (see README for setup)
rather than OpenAI/Claude, so there's no API key or billing required to run
this. The staged build plan calls the OpenAI/Claude route "fine for now" —
swapping providers later is a one-line change since langchain_ollama.ChatOllama
and e.g. langchain_openai.ChatOpenAI both implement the same interface.

The loop below is intentionally simple (no LangGraph yet — that's Stage 1):
  1. send the user's message + tool definitions to the LLM
  2. if the LLM asks to call a tool, run it and feed the result back
  3. repeat until the LLM answers directly, or MAX_TOOL_ITERATIONS is hit
"""
from __future__ import annotations

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_ollama import ChatOllama

from app import config
from app.tools import ALL_TOOLS

SYSTEM_PROMPT = """You are an internal HR assistant for Acme Corp.

You have three tools:
- search_policies: for questions about company policy/rules (remote work, PTO, expenses, code of conduct, security).
- search_employee: for questions about a specific person (their manager, department, title, email).
- list_documents: to see what policy documents exist.

Always use a tool to look up information before answering — never guess or
make up policy details or employee information. If the tools don't return
enough information to answer confidently, say so plainly instead of
inventing an answer. Keep answers concise and cite which document a policy
answer came from when relevant.
"""

_TOOLS_BY_NAME = {t.name: t for t in ALL_TOOLS}


def _build_llm():
    llm = ChatOllama(
        model=config.OLLAMA_CHAT_MODEL,
        base_url=config.OLLAMA_BASE_URL,
        temperature=0,
    )
    return llm.bind_tools(ALL_TOOLS)


def run_agent(user_message: str) -> dict:
    """Run the tool-calling loop for a single user message.

    Returns a dict: {"answer": str, "tool_calls": [ {name, args, result}, ... ]}
    so the FastAPI layer (and Streamlit UI) can show which tools fired —
    useful for the Stage 0 acceptance test ("does the right question hit the
    right tool?").
    """
    llm_with_tools = _build_llm()
    messages: list = [SystemMessage(content=SYSTEM_PROMPT), HumanMessage(content=user_message)]
    tool_call_log: list[dict] = []

    for _ in range(config.MAX_TOOL_ITERATIONS):
        response: AIMessage = llm_with_tools.invoke(messages)
        messages.append(response)

        tool_calls = getattr(response, "tool_calls", None) or []
        if not tool_calls:
            return {"answer": response.content, "tool_calls": tool_call_log}

        for call in tool_calls:
            tool_name = call["name"]
            tool_args = call.get("args", {})
            tool_fn = _TOOLS_BY_NAME.get(tool_name)

            if tool_fn is None:
                result = f"Error: unknown tool '{tool_name}'"
            else:
                try:
                    result = tool_fn.invoke(tool_args)
                except Exception as exc:  # keep the loop alive on a bad tool call
                    result = f"Error running {tool_name}: {exc}"

            tool_call_log.append({"name": tool_name, "args": tool_args, "result": result})
            messages.append(
                ToolMessage(content=str(result), tool_call_id=call["id"])
            )

    # Ran out of iterations without a final answer.
    return {
        "answer": (
            "I wasn't able to reach a final answer within the allowed number of "
            "tool calls. Please try rephrasing your question."
        ),
        "tool_calls": tool_call_log,
    }
